# Core utilities and database handling
